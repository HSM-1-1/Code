function [Z,iter,mu1,mu2,rho, Error_ZC,Error_ZQ,Error_ZT, Error_LAP] = solve_problem(X,M,pp,k1, lambda1, lambda2, lambda3,p,q)
% INPUT:
% X sample imaging data, every lateral slice in Y corresponds to one sample
% M: dissimilarity matrix calculated from the data
% OUTPUT:
% Z: coefficient tensor
[D,N,nV] = size(X);
%% ============================ Initialization ============================
for k=1:nV
    Z(:,:,k) = zeros(N,N);
    C(:,:,k) = zeros(N,N);
    G1(:,:,k) = zeros(N,N);
    G2(:,:,k)  = zeros(N,N);
    G3(:,:,k)  = zeros(N,N);
    Q(:,:,k) = zeros(N,N);
    T(:,:,k)  =zeros(N,N);
    % T(:,:,k)  = sqrt(0.5)*randn(N,N);
    E(:,:,k) = zeros(D,N);
    Y(:,:,k) = zeros(D,N);
end
oldZ = Z; oldC = C; oldQ = Q; oldT = T; oldE=E;
Isconverg = 0;epson = 1e-5;

iter = 0;
mu1 = 1e-4;max_mu =1e10; 
mu2 =1e-5;  max_mu =1e10; 
rho = 1.8; 
ww=ones(nV,1);
%% new add
%% normalize each lateral slice of tensor Y
for i=1:1:N
    for j=1:1:D
        for k=1:1:nV
            barX(j,i,k)=X(j,i,k)/norm(X(:,i,:),'fro');
        end
    end
end

    Weightk = constructW_PKN_bvecWJY(barX,X, 5); 

%% ================================ Upadate ===============================
while(Isconverg == 0)

    %% ============================== Upadate Z ===============================
    P1= C - G1/mu1;
    P2 = Q-G2/mu1;
    P3 = T-G3/mu1;
    O = X - E +Y/mu2;
    P1hat = fft( P1,[],3);
    P2hat = fft(P2,[],3);
    P3hat = fft(P3,[],3);
    Ohat = fft(O,[],3);
    Xhat = fft(X,[],3);
    for i=1:nV
        shat(:,:,i) = inv(3*mu1.*eye(N,N)+mu2.*Xhat(:,:,i)'*Xhat(:,:,i))*(mu1*( P1hat(:,:,i)+ P2hat(:,:,i)+ P3hat(:,:,i))+mu2*Xhat(:,:,i)'*Ohat(:,:,i));
    end
    clear i
    Z = ifft(shat,[],3);
    %% add new 另对角线元素为0

    for i = 1:nV
        Z(:,:,i)=Z(:,:,i)-diag(diag(Z(:,:,i)));
    end

    %% ============================== Upadate E===============================
    for i=1:nV
        tempXZ(:,:,i)=Xhat(:,:,i)*shat(:,:,i);
    end
    clear i
    x_con_z = ifft(tempXZ,[],3);
    for i=1:nV
        E(:,:,i) = solve_l2p(X(:,:,i)- x_con_z(:,:,i)+Y(:,:,i)./mu2,lambda2/mu2,pp);
    end
 
    %% ============================== Upadate C ===============================
    A = Z + G1/mu1;
    [C,sp,trank] = prox_tnn_shiftdim(A,ww/mu1,p,3);
   
   %% ============================== Upadate Q===============================
   Qtemp = Z + G2/mu1;
   for i = 1:nV
        Q(:,:,i) =  solve_Lp_WJY( Qtemp(:,:,i), (lambda1/mu1).*M, q);
    end
   
   D = zeros(N,N,nV);
   %% =========================== Upadate T^k ===============================
   for i = 1:nV
          % B(:,:,i) = constructW_PKN(Z(:,:,i),k1);
          B(:,:,i) = Weightk;
          for j = 1:N
              D(j,j,i) =sum(B(j,:,i));
          end
    end
    for i = 1:nV
        L(:,:,i) = D(:,:,i) -B(:,:,i); 
        T(:,:,i) =(mu1*Z(:,:,i) +G3(:,:,i))*inv(mu1*eye(N,N)+2*lambda3*L(:,:,i)) ;
    end
    clear k
    %% ============================== Upadate G1,G2 , G3===============================
    G1 = G1 + mu1*(Z - C);
    G2 = G2 + mu1*(Z - Q);
    G3 = G3 + mu1*(Z - T);
    Y = Y+mu2*(X-x_con_z-E);
    %% ============================== Recording ===============================
    % objV = objV + 2*alpha*trace(F'*L*F);
    %    history.objval(iter+1)   =  objV;

    %% ====================== Checking Coverge Condition ======================
    con_1= X-x_con_z-E;
    con_2 = Z - C;
    con_3 = Z - Q;
    con_4= Z - T;
    con_z = Z - oldZ;
    con_c = C - oldC;
    con_q = Q - oldQ;
    con_t  = T - oldT;
    con_E = E - oldE;
    tem_con = [norm(con_1(:),'inf'),norm(con_2(:),'inf'),norm(con_3(:),'inf'),norm(con_4(:),'inf'),norm(con_z(:),'inf'),norm(con_c(:),'inf'),norm(con_q(:),'inf'),norm(con_t(:),'inf')];
    if (iter>500) || max(tem_con)<=epson
        Isconverg  = 1;
    end
    mu1 = min(rho*mu1,max_mu);
    mu2 = min(rho*mu2,max_mu);
    oldZ = Z; oldC = C; oldQ = Q; oldT = T; 
    iter = iter + 1;  
    Error_ZC(1,iter)=[tem_con(2)]; 
    Error_ZQ(1,iter)=[tem_con(3)]; 
    Error_ZT(1,iter)=[tem_con(4)]; 
    Error_LAP(1,iter)=[tem_con(1)]; 
end
% %% new add   
%     stopC = max([ max(max(max(abs(Z - C)))), max(max(max(abs(Z - Q)))),max(max(max(abs(Z - T)))), max(max(max(abs(Z - oldZ)))), max(max(max(abs(C - oldC)))), max(max(max(abs(Q - oldQ)))), max(max(max(abs(T - oldT)))), max(max(max(abs(J - oldJ)))), max(Error_JTK)] );
% 
%     if stopC<epsilon
%         break;
%     else
%     G1 = G1 + mu1*(Z - C);
%     G2 = G2 + mu1*(Z - Q);
%     G3 = G3 + mu1*(Z - T);
%     Y = Y+mu2*(X-x_con_z-E);
%         mu1 = min(rho*mu1, mu_max);
%         mu2 = min(rho*mu2, mu_max);
%         oldZ = Z; oldC = C; oldQ = Q; oldT = T; 
%     end
% 
% Error_ZC(1,iter)=[max(max(max(abs(Z - C))))];    
% Error_ZQ(1,iter)=[max(max(max(abs(Z - Q))))]; 
% Error_ZT(1,iter)=[max(max(max(abs(Z - T))))]; 
% Error_SSG(1,iter)=[max(Error_JTK)]; 
% 
% end
% end
