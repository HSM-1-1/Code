function [Data]=NormalizeData(X)
[n1,n2,n3] = size(X);
for i=1:1:n1
    for j=1:1:n2
        for k=1:1:n3
            Data(i,j,k)=X(i,j,k)/norm(X(:,j,:),'fro');
        end
    end
end
