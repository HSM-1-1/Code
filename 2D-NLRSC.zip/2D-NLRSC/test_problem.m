clear all
close all
clc
clear
addpath(genpath(cd))
%% 数据集
%load('Tensor_PIEclass15per49_tran32,735,32.mat');
%load('Tensor_coil20tran_1440_WJYmade01.mat')
load('Tensor_JAFFEtran_23,200,23_WJYmade.mat')

data =JAFFE200;
clustern=max(unique(gnd));
gt=gnd;
vecdata = zeros(size(data,1)*size(data,3), size(data,2));
for i = 1:size(data,2)
    temp = data(:,i,:);
    vecdata(:,i) = temp(:);
end

vecdata = vecdata./repmat(sqrt(sum(vecdata.^2)),[size(data,1)*size(data,3) 1]);
L = vecdata'*vecdata;
sigma = mean(mean(1 - L));
M = ones(size(L)) - exp(-(ones(size(L))-L)/sigma);
M=M-diag(diag(M));
%% parameter
Num=0;
k1 = 5;
%% JAFFE
lambda1 =0.0001;
lambda2 =0.001;
lambda3 = 0.0001;
pp=0.9; q=0.9;p=0.5;

%%  Experiment
Tiao_can_result_4 =[];
%     for p = 0.1:0.1:1
%           for q = 0.1:0.1:1
%               for pp = 0.1:0.1:1
% for ii =1:length(lambda1_list)
%         for i =1:length(lambda2_list)
%             for j = 1:length(lambda3_list)
% num_runs = 5;  % 随机初始化运行5次
% accuracies = zeros(num_runs, 1);
% iterations_list = zeros(num_runs, 1);
% for run = 1:num_runs
 % for   k1 = 5:5:30
                Num = Num+1;
                % lambda1 = lambda1_list(ii);
                % lambda2 = lambda2_list(i);
                % lambda3 = lambda3_list(j);
                % fprintf('lambda1: %f, lambda2: %f,  mu: %f, rho: %f',...
                %     lambda1,lambda2,mu,rho);
                % fprintf('Num=%f,lambda1 =%f,lambda2 =%f,mu =%f,rho =%f,mu2 =%f,lambda3 =%f,\n',Num,lambda1,lambda2,mu,rho,mu2,lambda3)
                %                 [Z,iter] = SCLRSmCWJYSSGnew(data, M, lambda1, lambda2, mu, rho, mu2, lambda3);
                %                 [Z,iter] = SCLRSmCWJYSSGnew_bvec_Lpnorm(data, M, lambda1, lambda2, mu, rho, mu2, lambda3);
                tic;
                [Z,iter,mu1,mu2,rho,Error_ZC,Error_ZQ,Error_ZT, Error_LAP] = solve_problem(data,M,pp,k1, lambda1, lambda2, lambda3,p,q);
                time = toc;
                affi = sqrt(sum(Z.^2,3));
                affi = (affi + affi');
                ACC_total = zeros(1,20);
                NMI_total = zeros(1,20);
                Purity_total = zeros(1,20);
                F_total = zeros(1,20);
                P_total = zeros(1,20);
                R_total = zeros(1,20);
                RI_total = zeros(1,20);
                for i_ave = 1:20
                    grps = SpectralClustering(affi,clustern);
                    result =  ClusteringMeasure(gt, grps);
                    ACC_total(i_ave) = result(1,1);
                    NMI_total(i_ave) = result(1,2);
                    Purity_total(i_ave) = result(1,3);
                    F_total(i_ave) = result(1,4);
                    P_total(i_ave) = result(1,5);
                    R_total(i_ave) = result(1,6);
                    RI_total(i_ave) = result(1,7);
                end
                ACC_mean = mean(ACC_total); ACC_std = std(ACC_total);
                NMI_mean = mean(NMI_total); NMI_std = std(NMI_total);
                Purity_mean = mean(Purity_total); Purity_std = std(Purity_total);
                F_mean = mean(F_total); F_std = std(F_total);
                P_mean = mean(P_total); P_std = std(P_total);
                R_mean = mean(R_total); R_std = std(R_total);
                RI_mean = mean(RI_total); RI_std = std(RI_total);

                Result{1,Num} = [ [lambda1;lambda2;lambda3;mu1;mu2;rho;iter;time;pp],[ACC_mean;NMI_mean;Purity_mean;F_mean;P_mean;R_mean;RI_mean;p;q] ];   
Tiao_can_result_4 = [ Tiao_can_result_4,[ACC_mean;NMI_mean] ];
 % end
% end

                % save('Result_Yale_2024_10_24.mat','Result','-v7.3')
            % end
        % end

% fprintf('ACC: %f(%f), NMI: %f(%f), Purity: %f(%f), F-Score: %f(%f), P: %f(%f), R: %f(%f), RI: %f(%f)\n',...
%     ACC_mean,ACC_std,NMI_mean,NMI_std,Purity_mean, Purity_std, F_mean,F_std,P_mean,P_std,R_mean,R_std,RI_mean,RI_std);
% 结果
% for i=1:1:244
%     Acct=Result{1,i}(1,2);
%     Acc(1,i)=Acct;
% end
% [num,index]=find(Acc==max(Acc));
% fprintf('ACC: %f(%f), NMI: %f(%f),  Purity: %f(%f), F-Score: %f(%f), P: %f(%f), R: %f(%f), RI: %f(%f)\n',...
%     ACC_mean,ACC_std,NMI_mean,NMI_std,Purity_mean, Purity_std, F_mean,F_std,P_mean,P_std,R_mean,R_std,RI_mean,RI_std);
%  绘图 
t=1:1:iter-1;


plot(Error_ZC,'--d','color',[34 139 34]/255,'LineWidth',1,'MarkerSize',4); % 缁胯壊
hold on
plot(Error_ZQ,'--o','color',[205 92 92]/255,'LineWidth',1,'MarkerSize',4); % 鐜孩
hold on
plot(Error_ZT,'--^','color',[255 174 0]/255,'LineWidth',1,'MarkerSize',4); % orange 姗橀粍鑹?
hold on
plot(Error_LAP,'--+','color',[0.3 0.5 1],'LineWidth',1,'MarkerSize',4); % orange 姗橀粍鑹?
xlabel('Number of iterations')
ylabel('Error')
legend(...
    '$||\mathcal{Z}-\mathcal{C}||_{\infty}$', ...
    '$||\mathcal{Z}-\mathcal{Q}||_{\infty}$', ...
    '$ ||\mathcal{Z}-\mathcal{T}||_{\infty}$', ...
    '$||\mathcal{X} - \mathcal{X}*\mathcal{Z} - \mathcal{E}||_{\infty}$', ...
    'Interpreter', 'latex');

