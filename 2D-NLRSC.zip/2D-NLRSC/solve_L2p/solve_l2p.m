function [E] = solve_l2p(W,lambda,p)
n = size(W,2);
E = W;
for i=1:n
    E(:,i) = solve_lp(W(:,i),lambda,p);
end
end

function [x] = solve_lp(y,lambda,p)
% min lambda |x|_2p + |x-w|_2^2
nw = norm(y);
tau   =  (2*lambda.*(1-p)).^(1/(2-p)) + p*lambda.*(2*(1-p)*lambda).^((p-1)/(2-p));
tem = y/nw;
J=2;
if nw>tau
    t=abs(nw);
    for  j  =  1 : J
        t    =  abs(nw) - p*lambda*(t)^(p-1);
    end
    tx  =  sign(nw).*t;
else
    tx = 0;
end
x = tem*tx;
end